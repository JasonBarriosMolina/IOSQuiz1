import UIKit

func sumParesImpares(array1: [Int]) -> Bool
{
    
    var arrayPares : [Int] = []
    var arrayImpares : [Int] = []
    
    for count in 1...array1.count - 1 {
        if (array1[count] % 2 == 0) {
            arrayPares.append(array1[count])
        }
        else
        {
            arrayImpares.append(array1[count])
        }

    }
    
//Falto sumar
    let sumpares = arrayPares.count
    
    let sumimpares = arrayImpares.count
    
    if (sumpares == sumimpares){
        return false
    }
    else if (sumpares <= sumimpares) {
        return false
    }
    else {
        return true
    }
}


func divisores(numero: Int) -> [Int] {
    
    var array: [Int] = [0]

    if (numero <= 0) {
        return array
    }
    else
    {
        for count in 1...numero {
            if (numero % count == 0) {
                array.append(array[count])
            }
        }
    }

    return array

}


func promedio(array: [Float]) -> [Float] {
    
    //Falto hacer el promedio
    var array: [Float] = []

    for count in 0...array.count - 1 {

    }

    return array

}
